create view emp_tbl as
  select `test`.`employee_tbl`.`LAST_NAME`   AS `last_name`,
         `test`.`employee_tbl`.`FIRST_NAME`  AS `first_name`,
         `test`.`employee_tbl`.`MIDDLE_NAME` AS `middle_name`
  from `test`.`employee_tbl`;

