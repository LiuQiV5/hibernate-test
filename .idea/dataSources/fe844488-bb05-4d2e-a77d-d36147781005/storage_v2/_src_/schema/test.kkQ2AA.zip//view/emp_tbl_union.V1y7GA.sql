create view emp_tbl_union as
  select `emp`.`LAST_NAME`   AS `last_name`,
         `emp`.`FIRST_NAME`  AS `first_name`,
         `emp`.`MIDDLE_NAME` AS `middle_name`,
         `empp`.`SALARY`     AS `salary`
  from `test`.`employee_tbl` `emp`
         join `test`.`employee_pay_tbl` `empp`
  where (`emp`.`EMP_ID` = `empp`.`EMP_ID`);

